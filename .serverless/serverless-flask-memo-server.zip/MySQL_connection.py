import mysql.connector

def get_cnx() :
    cnx = mysql.connector.connect(
        host = 'learn-db.cbdfurkch0nx.ap-northeast-2.rds.amazonaws.com',
        database = 'memo',
        user = 'memo_learn',
        password = '7913'
    )
    return cnx